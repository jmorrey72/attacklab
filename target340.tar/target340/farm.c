/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_169(unsigned x)
{
    return x + 3281293400U;
}

unsigned getval_116()
{
    return 3347663065U;
}

unsigned addval_338(unsigned x)
{
    return x + 3281031288U;
}

void setval_107(unsigned *p)
{
    *p = 2428995912U;
}

unsigned getval_371()
{
    return 3281016955U;
}

void setval_130(unsigned *p)
{
    *p = 4089665582U;
}

unsigned getval_495()
{
    return 3284633920U;
}

void setval_140(unsigned *p)
{
    *p = 2462550344U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

void setval_369(unsigned *p)
{
    *p = 2462222721U;
}

void setval_178(unsigned *p)
{
    *p = 3252717896U;
}

void setval_332(unsigned *p)
{
    *p = 3223899785U;
}

void setval_412(unsigned *p)
{
    *p = 3767093296U;
}

void setval_223(unsigned *p)
{
    *p = 3526414729U;
}

unsigned getval_424()
{
    return 3372794505U;
}

void setval_427(unsigned *p)
{
    *p = 3353381192U;
}

void setval_387(unsigned *p)
{
    *p = 3281047945U;
}

unsigned addval_254(unsigned x)
{
    return x + 3229929097U;
}

unsigned getval_491()
{
    return 2497743176U;
}

unsigned addval_200(unsigned x)
{
    return x + 3286272264U;
}

void setval_166(unsigned *p)
{
    *p = 3674787464U;
}

unsigned addval_415(unsigned x)
{
    return x + 3676361113U;
}

void setval_188(unsigned *p)
{
    *p = 2430634824U;
}

void setval_122(unsigned *p)
{
    *p = 3531919001U;
}

void setval_120(unsigned *p)
{
    *p = 3285289165U;
}

unsigned addval_324(unsigned x)
{
    return x + 3281113481U;
}

unsigned getval_497()
{
    return 3229929099U;
}

unsigned getval_257()
{
    return 3221799560U;
}

void setval_365(unsigned *p)
{
    *p = 3380924809U;
}

unsigned addval_403(unsigned x)
{
    return x + 3523268233U;
}

unsigned addval_189(unsigned x)
{
    return x + 2428635417U;
}

void setval_236(unsigned *p)
{
    *p = 3223372425U;
}

unsigned getval_343()
{
    return 3229926089U;
}

unsigned addval_416(unsigned x)
{
    return x + 2430634312U;
}

unsigned getval_474()
{
    return 3523789465U;
}

void setval_155(unsigned *p)
{
    *p = 3376988809U;
}

void setval_437(unsigned *p)
{
    *p = 2464188744U;
}

unsigned getval_386()
{
    return 3515571116U;
}

void setval_472(unsigned *p)
{
    *p = 2429454719U;
}

unsigned getval_315()
{
    return 3221802649U;
}

void setval_157(unsigned *p)
{
    *p = 3678982537U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
